import java.awt.Color;
import java.awt.Dimension;
import java.io.IOException;

import javax.swing.*;

public class Runner {

	public static void main(String[] args) {
		/*Bulb bulb1= new Bulb(false,Color.RED, "red");
		System.out.println(bulb1);
		bulb1.turnOn();
		System.out.println(bulb1.toString());
		
		TrafficLight light=new TrafficLight();
		light.nextState();
		light.nextState();
		System.out.println(light.getLights()[0]);
		System.out.println(light.getLights()[1]);
		System.out.println(light.getLights()[2]);
		System.out.println(light.toString());*/
		
		
		//SmartTrafficInterval smart=new SmartTrafficInterval();
		//System.out.println(smart.getCurrentDay()+" "+smart.getCurrentTimeInterval());
		
		JFrame frame=new JFrame("Traffic Light");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		/*JPanel panel=new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setPreferredSize(new Dimension(280,220));
		JLabel lable1= new JLabel("Traffic Light");
		panel.add(lable1);
		frame.getContentPane().add(panel);*/
		TrafficLightPanel panel= new TrafficLightPanel();
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
		//smart.readDataFromFile();
		
		

	}

}
